package com.project.tfa;

public class LogonDataBean {
	private String id;
	private String password;
	private String building;
      
	public String getId() 
    { return id; }

    public void setId(String id) 
    { this.id = id; }

    public String getPasswd() 
    { return password; }

    public void  setPasswd(String passwd) 
    { this.password = passwd; }
    
    public String getBuilding() 
    { return building; }

    public void setBuilding(String building) 
    { this.building = building; }
}
